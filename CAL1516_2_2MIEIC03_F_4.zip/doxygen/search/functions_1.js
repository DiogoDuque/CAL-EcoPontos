var searchData=
[
  ['calcweight',['calcWeight',['../class_coord.html#a2bdb34b9edbd09b917c7c1a9d723eaa4',1,'Coord']]]
];
