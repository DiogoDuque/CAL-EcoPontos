var searchData=
[
  ['ecoponto',['Ecoponto',['../class_ecoponto.html#a77182257dfc416589972bd4207142f6b',1,'Ecoponto::Ecoponto()'],['../class_ecoponto.html#aa22ed326556db71e993a171c420c4dc0',1,'Ecoponto::Ecoponto(int trash, int id)']]]
];
